Program:sheetweavingspecs.exe
Program Author:Latish Sherigar
emailid:latishsherigar@yahoo.co.in
website:http://www.geocities.com/latishsherigar


Help-:

During the first use the word douments directory and excel filename has to be given.The program remembers the settings once given.

The program can be started by pressing the Start button or choosing start from the Action menu.

The program can be stopped in between by pressing the Stop button or choosing stop from the Action menu.

The current details of the program are shown in the details list box.